from pickle import GET
from flask import Flask, render_template, request
import pickle
import numpy as np
import pandas as pd


app = Flask(__name__)

@app.route('/', methods=['POST', 'GET'] )
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST','GET'] )
def predict():
    h = request.form['h']
    a = request.form['a']
    h_model = pickle.load(open('/Users/Hyungdanny/Desktop/ai/project03/flask_d/h_model.pkl','rb'))
    a_model = pickle.load(open('/Users/Hyungdanny/Desktop/ai/project03/flask_d/a_model.pkl','rb'))
    onehot_df = pickle.load(open('/Users/Hyungdanny/Desktop/ai/project03/flask_d/onehot_df.pkl','rb'))
    fifa_ranking_df = pickle.load(open('/Users/Hyungdanny/Desktop/ai/project03/flask_d/fifa_ranking_df.pkl','rb'))
    
    cols = ['neutral', 'home_rank', 'away_rank', 'friendly','FIFA World Cup','home_point','away_point']
    for c in onehot_df.columns.to_list():
        cols.append(c)
    df = pd.DataFrame(np.zeros((1,len(cols)), dtype=int), columns=cols)
    if neutral:
        df.neutral.iloc[0] = 1
    else:
        df.neutral.iloc[0] = 0
        df.home_rank.iloc[0] = fifa_ranking_df[((fifa_ranking_df.rank_date == '2021-05-27') & (fifa_ranking_df.country_full == h_team))]['rank'].values[0]
        df.away_rank.iloc[0] = fifa_ranking_df[((fifa_ranking_df.rank_date == '2021-05-27') & (fifa_ranking_df.country_full == a_team))]['rank'].values[0]
        df['home_team_'+h].iloc[0] = 1
        df['away_team_'+a].iloc[0] = 1
    #df = df[hmodel.get_booster().feature_names]
    # predict
        hscore = int(h_model.predict(df.iloc[0].to_numpy().reshape(1,91))[0])
        ascore = int(a_model.predict(df.iloc[0].to_numpy().reshape(1,91))[0])
    return render_template('index.html',  hscore = hscore, ascore = ascore)

if __name__=="__main__":
    app.run(debug=True)